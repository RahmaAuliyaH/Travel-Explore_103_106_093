package com.example.travelexplore

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Satu-satunya footer menu untuk seluruh aplikasi. */
enum class AppTab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Rounded.Home),
    Explore("Explore", Icons.Rounded.Explore),
    Booking("Booking", Icons.Rounded.CalendarMonth),
    Settings("Settings", Icons.Rounded.Settings),
}

private val NavInk = Color(0xFF1A1A1A)

/** Navigasi bawah melayang: item aktif memanjang + label. */
@Composable
fun FloatingNav(selected: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(30.dp)
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .widthIn(max = 520.dp)
            .fillMaxWidth()
            .shadow(18.dp, shape, ambientColor = Color.Black.copy(alpha = 0.2f))
            .background(Color.White, shape)
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppTab.entries.forEach { tab ->
            val isSel = tab == selected
            val bg by animateColorAsState(if (isSel) NavInk else Color.Transparent, label = "navBg")
            val fg by animateColorAsState(if (isSel) Color.White else Color(0xFF9A9AA3), label = "navFg")
            Row(
                Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(bg)
                    .clickable { onSelect(tab) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(tab.icon, tab.label, tint = fg, modifier = Modifier.size(22.dp))
                AnimatedVisibility(visible = isSel) {
                    Text(
                        tab.label,
                        modifier = Modifier.padding(start = 8.dp),
                        color = fg, fontFamily = FontFamily.Default,
                        fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
    }
}

/** Navigasi samping untuk layar lebar (tablet / HP landscape). */
@Composable
fun SideRail(selected: AppTab, onSelect: (AppTab) -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxHeight()
            .width(88.dp)
            .background(Color.White)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(vertical = 12.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AppTab.entries.forEach { tab ->
            val isSel = tab == selected
            val fg = if (isSel) Color.White else Color(0xFF9A9AA3)
            Column(
                Modifier
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (isSel) NavInk else Color.Transparent)
                    .clickable { onSelect(tab) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(tab.icon, tab.label, tint = fg, modifier = Modifier.size(22.dp))
                Text(tab.label, color = fg, fontSize = 10.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}
