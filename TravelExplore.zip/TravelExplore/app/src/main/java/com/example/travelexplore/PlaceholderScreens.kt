package com.example.travelexplore

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Halaman sementara untuk menu yang belum dibuat (Settings). */
@Composable
fun PlaceholderScreen(title: String) {
    Box(
        Modifier.fillMaxSize().background(Color(0xFFF6F6F8)),
        contentAlignment = Alignment.Center,
    ) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1A1A1A))
    }
}
