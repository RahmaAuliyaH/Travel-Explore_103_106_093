package com.example.travelexplore


import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*


import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF202124)
private val Muted = Color(0xFF96999E)
private val Orange = Color(0xFFEF7650)
private val Page = Color(0xFFF8F8F7)

private data class HomeTour(
    val title: String,
    val subtitle: String,
    val image: Int,
    val price: String
)

@Composable
fun HomeScreen(onTourClick: () -> Unit = {}) {
    val context = LocalContext.current
    val onMessage: (String) -> Unit = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    var selectedCategory by remember { mutableStateOf("Trip") }
    var showNotifications by remember { mutableStateOf(false) }
    var showAll by remember { mutableStateOf(false) }
    val favorites = remember { mutableStateListOf<String>() }


    val tours = listOf(
        HomeTour("Lava Jeep Tour", "JEEP TOUR AROUND BROMO", R.drawable.jeep, "Rp 350.000"),
        HomeTour("Beauty of Bromo", "BEAUTY OF BROMO", R.drawable.beauty_bromo, "Rp 250.000"),
        HomeTour("Sunrise Point", "BROMO SUNRISE EXPERIENCE", R.drawable.sunrise_bromo, "Rp 200.000"),
    )


    BoxWithConstraints(Modifier.fillMaxSize().background(Page)) {
        // Adaptif: tinggi hero & jumlah kolom kartu mengikuti ukuran layar
        val heroHeight = minOf(maxWidth * 0.5f, maxHeight * 0.4f).coerceIn(150.dp, 300.dp)
        val columns = if (maxWidth >= 560.dp) 2 else 1
        val bottomPad = LocalContentBottomPadding.current
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Page)
        ) {
            // Hero header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(heroHeight)
            ) {
                Image(
                    painter = painterResource(
                        id = R.drawable.bromo_mountain
                    ),
                    contentDescription = "bromo_mountain",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0x22000000), Color(0xB8000000)),
                                startY = 0f
                            )
                        )
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.9f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Person, contentDescription = "Profil", tint = Ink)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(
                        onClick = { showNotifications = !showNotifications },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.22f))
                    ) {
                        Icon(Icons.Filled.NotificationsNone, contentDescription = "Notifikasi", tint = Color.White)
                    }
                }
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 20.dp, bottom = 17.dp)
                ) {
                    Text("Explore Tourism", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("East Java, Indonesia", color = Color.White, fontSize = 11.sp)
                    }
                }
            }

            if (showNotifications) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Notifications, contentDescription = null, tint = Orange)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Notifikasi", fontWeight = FontWeight.SemiBold)
                            Text("Belum ada notifikasi baru.", fontSize = 12.sp, color = Muted)
                        }
                        IconButton(onClick = { showNotifications = false }) {
                            Icon(Icons.Filled.Close, contentDescription = "Tutup")
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .wrapContentWidth(Alignment.CenterHorizontally)
                    .widthIn(max = 840.dp)
                    .padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(12.dp))
                // Balance / promo strip
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f).clickable { onMessage("Saldo Anda: Rp 991.000") },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = Ink, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(9.dp))
                            Column {
                                Text("BALANCE", fontSize = 9.sp, color = Muted, letterSpacing = 0.6.sp)
                                Text("Rp 991.000", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Ink)
                            }
                        }
                        Box(Modifier.width(1.dp).height(32.dp).background(Color(0xFFECECEC)))
                        Row(
                            modifier = Modifier.weight(1f).clickable { onMessage("Anda memiliki 14 kode promo") }.padding(start = 13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.LocalOffer, contentDescription = null, tint = Ink, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text("PROMO", fontSize = 9.sp, color = Muted, letterSpacing = 0.6.sp)
                                Text("14 Code", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Ink)
                            }
                            Icon(Icons.Filled.ChevronRight, contentDescription = "Lihat promo", modifier = Modifier.size(16.dp))
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Category", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Ink)
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (showAll) "Show Less" else "View All",
                        color = Muted,
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { showAll = !showAll }
                    )
                }
                Spacer(Modifier.height(9.dp))
                val categories = if (showAll) listOf("Trip", "Hotel", "Train", "Flight", "Camping", "Food") else listOf("Trip", "Hotel", "Train", "Flight")
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { category ->
                        val emoji = when (category) {
                            "Trip" -> "🚙"
                            "Hotel" -> "🏨"
                            "Train" -> "🚆"
                            "Flight" -> "✈"
                            "Camping" -> "🏕"
                            else -> "🍜"
                        }
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedCategory == category) Ink else Color.White)
                                .clickable {
                                    selectedCategory = category
                                    if (category != "Trip") onMessage("Kategori $category dipilih")
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(emoji, fontSize = 12.sp)
                            Spacer(Modifier.width(5.dp))
                            Text(
                                category,
                                color = if (selectedCategory == category) Color.White else Color(0xFF8C8F93),
                                fontSize = 11.sp,
                                fontWeight = if (selectedCategory == category) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                val visibleTours = if (selectedCategory == "Trip") tours else tours.take(1).map {
                    it.copy(title = "$selectedCategory in Bromo", subtitle = "EXPLORE $selectedCategory")
                }
                visibleTours.chunked(columns).forEach { rowTours ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowTours.forEach { tour ->
                            val isFavorite = favorites.contains(tour.title)
                            Box(Modifier.weight(1f)) {
                                HomeTourCard(
                                    tour = tour,
                                    isFavorite = isFavorite,
                                    onFavorite = {
                                        if (isFavorite) favorites.remove(tour.title) else favorites.add(tour.title)
                                    },
                                    onClick = onTourClick
                                )
                            }
                        }
                        repeat(columns - rowTours.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                Spacer(Modifier.height(bottomPad))
            }
        }
    }
}

@Composable
private fun HomeTourCard(
    tour: HomeTour,
    isFavorite: Boolean,
    onFavorite: () -> Unit,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(15.dp))
            .clickable(onClick = onClick)
    ) {
        Image(
            painter = painterResource(id = tour.image),
            contentDescription = tour.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color(0xAA000000)),
                    startY = 80f
                )
            )
        )
        Text(
            tour.subtitle,
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 9.sp,
            letterSpacing = 0.5.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 15.dp, bottom = 36.dp)
        )
        Text(
            tour.title,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 15.dp, bottom = 14.dp)
        )
        IconButton(
            onClick = onFavorite,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .size(28.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.35f))
        ) {
            Icon(
                if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = if (isFavorite) "Hapus dari favorit" else "Tambah ke favorit",
                tint = if (isFavorite) Color(0xFFFF5757) else Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
        Row(
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 13.dp),
            horizontalArrangement = Arrangement.spacedBy((-5).dp)
        ) {
            listOf(Color(0xFFD7B29C), Color(0xFF9EAAA0), Color(0xFFE8D4B5)).forEach {
                Box(
                    modifier = Modifier.size(19.dp).clip(CircleShape).background(it),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                }
            }
        }
    }
}


@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    MaterialTheme {
        HomeScreen()
    }
}