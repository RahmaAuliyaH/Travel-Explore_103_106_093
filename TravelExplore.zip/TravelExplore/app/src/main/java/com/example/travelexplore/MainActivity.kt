package com.example.travelexplore

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.travelexplore.ui.theme.TravelExploreTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Aplikasi ini hanya bertema terang: ikon status bar dibuat gelap agar terbaca
        // walau HP dalam mode gelap.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
        )
        setContent {
            TravelExploreTheme(darkTheme = false, dynamicColor = false) {
                AppRoot(onExit = { finish() })
            }
        }
    }
}

@Composable
private fun AppRoot(onExit: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(AppTab.Home) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val useRail = maxWidth >= RailBreakpoint

        CompositionLocalProvider(
            LocalContentBottomPadding provides (if (useRail) 24.dp else 120.dp)
        ) {
            if (useRail) {
                // Layar lebar: menu di samping, konten mengisi sisanya
                Row(Modifier.fillMaxSize()) {
                    SideRail(selected = tab, onSelect = { tab = it })
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        AppScreens(tab, onTab = { tab = it }, onExit = onExit)
                    }
                }
            } else {
                // HP portrait: footer menu melayang di bawah
                Box(Modifier.fillMaxSize()) {
                    AppScreens(tab, onTab = { tab = it }, onExit = onExit)
                    FloatingNav(
                        selected = tab,
                        onSelect = { tab = it },
                        modifier = Modifier.align(Alignment.BottomCenter),
                    )
                }
            }
        }
    }
}

@Composable
private fun AppScreens(tab: AppTab, onTab: (AppTab) -> Unit, onExit: () -> Unit) {
    when (tab) {
        AppTab.Home -> HomeScreen(
            onTourClick = { onTab(AppTab.Explore) }, // kartu trip di Home -> tab Explore
        )
        AppTab.Explore -> ExploreScreen(
            onBack = onExit,
            onBook = { onTab(AppTab.Booking) }, // tombol kalender di detail -> tab Booking
        )
        AppTab.Booking -> BookingScreen(
            onAddBooking = { onTab(AppTab.Explore) }, // tombol "+" -> pilih trip di Explore
        )
        AppTab.Settings -> PlaceholderScreen("Settings")
    }
}
