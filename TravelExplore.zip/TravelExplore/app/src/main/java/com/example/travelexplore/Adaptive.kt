package com.example.travelexplore

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Lebar layar minimum (dp) untuk beralih dari footer melayang ke side rail. */
val RailBreakpoint: Dp = 600.dp

/**
 * Ruang kosong di bawah konten agar tidak tertutup footer melayang.
 * Di layar lebar (side rail) nilainya kecil karena tidak ada footer di bawah.
 */
val LocalContentBottomPadding = compositionLocalOf { 120.dp }
