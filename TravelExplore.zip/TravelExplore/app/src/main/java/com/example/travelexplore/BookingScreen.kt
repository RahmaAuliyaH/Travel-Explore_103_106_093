package com.example.travelexplore

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ==================== MODEL DATA ====================
data class Booking(
    val id: String,
    val title: String,
    val date: String,

    val guests: String,
    val price: String,
    val status: String,
    val statusColor: Color,
    val imageRes: Int,
    val isUpcoming: Boolean,
    val day: Int // tanggal (Oktober 2026) untuk penanda di kalender
)

// Data contoh (2 booking)
val sampleBookings = listOf(
    Booking(
        id = "BRM-1018",
        title = "Hiking On Mount Bromo",
        date = "Sun, 18 Oct 2026 · 03:00",
        guests = "2 guests · Cemoro Lawang",
        price = "Rp 385.000",
        status = "Confirmed",
        statusColor = Color(0xFF2E7D32),
        imageRes = R.drawable.bromo,
        isUpcoming = true,
        day = 18
    ),
    Booking(
        id = "BRM-1024",
        title = "Lava Jeep Tour",
        date = "Sat, 24 Oct 2026 · 04:00",
        guests = "4 guests · Savanna & Whispering Sands",
        price = "Rp 665.000",
        status = "Pending payment",
        statusColor = Color(0xFFE65100),
        imageRes = R.drawable.jeep,
        isUpcoming = true,
        day = 24
    )
)

// Warna penanda kalender, sama dengan legenda: Confirmed hitam, Pending oranye, Completed abu-abu
private fun markerColor(b: Booking): Color = when {
    !b.isUpcoming -> Color(0xFF9E9E9E)
    b.status.startsWith("Pending") -> Color(0xFFE65100)
    else -> Color.Black
}

// ==================== LAYAR UTAMA ====================
@Composable
fun BookingScreen(onAddBooking: () -> Unit = {}) {
    // State untuk tab filter (Upcoming, Completed, Cancelled)
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Upcoming", "Completed", "Cancelled")

    // State untuk tanggal yang dipilih di kalender
    var selectedDay by remember { mutableIntStateOf(11) }

    // Footer menu sekarang satu untuk semua halaman (lihat AppNavigation.kt / MainActivity),
    // jadi di sini tidak ada lagi bottomBar.
    Box(Modifier.fillMaxSize().background(Color(0xFFF5F5F5))) {
    LazyColumn(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .widthIn(max = 640.dp) // di layar lebar, konten tetap nyaman dibaca
            .fillMaxWidth()
            .fillMaxHeight()
            .statusBarsPadding()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { HeaderSection(onAdd = onAddBooking) }
        item { CalendarSection(selectedDay = selectedDay, onDaySelected = { selectedDay = it }) }
        item { FilterTabs(tabs = tabs, selectedIndex = selectedTab, onTabSelected = { selectedTab = it }) }

        items(sampleBookings.filter { booking ->
            when (selectedTab) {
                0 -> booking.isUpcoming
                1 -> !booking.isUpcoming
                else -> false // Cancelled tidak ada datanya
            }
        }) { booking ->
            BookingCard(booking = booking)
        }

        // Ruang di akhir agar tidak tertutup footer menu yang melayang
        item { Spacer(modifier = Modifier.height(LocalContentBottomPadding.current)) }
    }
    }
}

// ==================== 1. HEADER ====================
@Composable
private fun HeaderSection(onAdd: () -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "My Bookings",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${sampleBookings.count { it.isUpcoming }} upcoming trips",
                fontSize = 14.sp,
                color = Color(0xFF757575)
            )
        }
        // Tombol bulat hitam dengan ikon "+"
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Color(0xFF212121))
                .clickable(onClick = onAdd),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add booking",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

// ==================== 2. KALENDER ====================
@Composable
private fun CalendarSection(selectedDay: Int, onDaySelected: (Int) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F0F0))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Bulan & Tombol Navigasi
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { /* bulan sebelumnya */ }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Prev", tint = Color.Gray)
                }
                Text(
                    text = "October 2026",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
                IconButton(onClick = { /* bulan berikutnya */ }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next", tint = Color.Gray)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Nama Hari (Senin - Minggu)
            val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                daysOfWeek.forEach { day ->
                    Text(text = day, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Grid Tanggal (5 baris x 7 kolom untuk Oktober 2026)
            // Oktober 2026 dimulai hari Kamis (1 Okt). Kita buat grid statis sederhana.
            val calendarDays = listOf(
                // Baris 1 (1 Okt = Kamis)
                null, null, null, 1, 2, 3, 4,
                // Baris 2
                5, 6, 7, 8, 9, 10, 11,
                // Baris 3
                12, 13, 14, 15, 16, 17, 18,
                // Baris 4
                19, 20, 21, 22, 23, 24, 25,
                // Baris 5
                26, 27, 28, 29, 30, 31, null
            )

            val markers = sampleBookings.associate { it.day to markerColor(it) }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                calendarDays.chunked(7).forEach { week ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        week.forEach { day ->
                            if (day != null) {
                                val isSelected = day == selectedDay
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) Color.White else Color.Transparent)
                                        .border(
                                            width = if (isSelected) 1.5.dp else 0.dp,
                                            color = if (isSelected) Color.Black else Color.Transparent,
                                            shape = CircleShape
                                        )
                                        .clickable { onDaySelected(day) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = day.toString(),
                                        fontSize = 14.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.Black else Color(0xFF424242)
                                    )
                                    // Titik penanda untuk tanggal yang punya booking
                                    markers[day]?.let { dot ->
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomCenter)
                                                .padding(bottom = 3.dp)
                                                .size(5.dp)
                                                .clip(CircleShape)
                                                .background(dot)
                                        )
                                    }
                                }
                            } else {
                                Spacer(modifier = Modifier.size(36.dp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Legenda
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendDot(color = Color.Black, label = "Confirmed")
                Spacer(modifier = Modifier.width(16.dp))
                LegendDot(color = Color(0xFFE65100), label = "Pending")
                Spacer(modifier = Modifier.width(16.dp))
                LegendDot(color = Color(0xFF9E9E9E), label = "Completed")
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 10.sp, color = Color.Gray)
    }
}

// ==================== 3. FILTER TABS ====================
@Composable
private fun FilterTabs(tabs: List<String>, selectedIndex: Int, onTabSelected: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        tabs.forEachIndexed { index, tab ->
            val isSelected = index == selectedIndex
            Button(
                onClick = { onTabSelected(index) },
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSelected) Color.Black else Color.White,
                    contentColor = if (isSelected) Color.White else Color.Black
                ),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                modifier = Modifier.height(40.dp)
            ) {
                Text(text = tab, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

// ==================== 4. KARTU BOOKING ====================
@Composable
private fun BookingCard(booking: Booking) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE0E0E0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Gambar Kiri (Bromo / Jeep)
            Image(
                painter = painterResource(id = booking.imageRes),
                contentDescription = booking.title,
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Informasi Kanan
            Column(modifier = Modifier.weight(1f)) {
                // Judul & Badge Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = booking.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF1A1A1A),
                        modifier = Modifier.weight(1f)
                    )
                    // Badge Status
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = booking.statusColor.copy(alpha = 0.1f),
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Text(
                            text = booking.status,
                            fontSize = 10.sp,
                            color = booking.statusColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(text = booking.date, fontSize = 12.sp, color = Color.Gray)
                Text(text = booking.guests, fontSize = 12.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(8.dp))

                // Kode Booking & Harga
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(text = booking.id, fontSize = 10.sp, color = Color.LightGray)
                        Text(text = booking.price, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    // Tombol "View ticket" hitam kecil
                    Button(
                        onClick = { /* aksi lihat tiket */ },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF212121)),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(text = "View ticket", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }
    }
}

// ==================== PREVIEW ====================
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PreviewBookingScreen() {
    MaterialTheme {
        BookingScreen()
    }
}