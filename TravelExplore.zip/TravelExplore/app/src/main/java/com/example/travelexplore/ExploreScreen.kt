package com.example.travelexplore

import android.transition.Explode
import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/* ------------------------------------------------------------------ */
/*  Tema sederhana                                                     */
/* ------------------------------------------------------------------ */

private val Ink = Color(0xFF1A1A1A)
private val Canvas = Color(0xFFF6F6F8)
private val FieldBg = Color(0xFFEFEFF3)
private val HeartRed = Color(0xFFFF4D6A)
private val Gold = Color(0xFFFFB800)

// Ganti dengan Poppins (res/font) agar sama persis dengan inspirasi:
// private val AppFont = FontFamily(Font(R.font.poppins_regular), Font(R.font.poppins_medium, FontWeight.Medium), ...)
private val AppFont = FontFamily.Default

/* ------------------------------------------------------------------ */
/*  Model & data contoh                                                */
/* ------------------------------------------------------------------ */

enum class Category(val label: String) {
    All("All"), Culture("Culture"), Nature("Nature"), Adventure("Adventure"), Food("Food")
}

data class Destination(
    val id: Int,
    val title: String,
    val subtitle: String,
    val category: Category,
    val rating: Double,
    val distance: String,
    val duration: String,
    val description: String,
    val gridHeight: Dp,
    val gradient: List<Color>,
    /** Isi dengan URL gambar atau biarkan null (akan tampil gradasi). */
    val imageUrl: String? = null,
    /** Gambar dari res/drawable, contoh: R.drawable.bromo_sunrise */
    @DrawableRes val imageRes: Int? = null,
)

private val sunrise = listOf(Color(0xFFE8A05A), Color(0xFF7A4A3A))
private val mist = listOf(Color(0xFF9AA5B1), Color(0xFF4A5560))
private val forest = listOf(Color(0xFF6E8B5E), Color(0xFF2F4030))
private val ember = listOf(Color(0xFFD9703B), Color(0xFF5A2A1E))
private val dusk = listOf(Color(0xFFB07AA1), Color(0xFF3B2F4A))

val sampleDestinations = listOf(
    Destination(1, "Kidung Tengger Dance", "Tengger Village", Category.Culture, 4.7, "12 km", "2h",
        "Traditional dance performed by the Tengger people during Yadnya Kasada, accompanied by gamelan and chants.",
        320.dp, sunrise,
        imageRes = R.drawable.kidungtenggerdance),
    Destination(2, "Luhur Poten Temple", "Bromo Sea of Sand", Category.Culture, 4.8, "9 km", "1h",
        "A Hindu temple standing alone at the foot of the volcano, where the annual Kasada offering begins.",
        270.dp, mist,
        imageRes = R.drawable.luhurpontentemple),
    Destination(3, "The Land Above The Clouds", "Penanjakan Viewpoint", Category.Nature, 4.9, "234 km", "9h 32m",
        "Catch the sunrise above a sea of clouds, with Bromo, Batok and Semeru lined up on the horizon.",
        260.dp, ember,
        imageRes = R.drawable.thelandabovetheclouds),
    Destination(4, "Hiking On Mount Bromo", "Cemoro Lawang", Category.Adventure, 4.8, "3 km", "3h",
        "Climb the 250 steps to the crater rim and look straight down into the smoking caldera.",
        190.dp, mist,
                imageRes = R.drawable.bromo),
    Destination(5, "Ride a Horse", "Sea of Sand", Category.Adventure, 4.6, "5 km", "1h 30m",
        "Cross the volcanic sand on horseback with a local guide, a classic way to reach the foot of the stairs.",
        230.dp, dusk,
        imageRes = R.drawable.horse),
    Destination(6, "Lava Jeep Tour", "Savanna & Whispering Sands", Category.Adventure, 4.9, "20 km", "4h",
        "Open-top 4x4 ride through Teletubbies hill, Whispering Sands and the crater viewpoint.",
        190.dp, forest,
        imageRes = R.drawable.jeep),
    Destination(7, "Madakaripura Waterfall", "Probolinggo", Category.Nature, 4.7, "38 km", "3h",
        "A hidden canyon waterfall, said to be where Gajah Mada meditated. Expect to get wet.",
        250.dp, forest,
                imageRes = R.drawable.makadipura),
    Destination(8, "Tumpak Sewu", "Lumajang", Category.Nature, 4.5, "1 km", "45m",
        "Hot ginger tea and grilled corn from the stalls near the rim. Best after a freezing sunrise.",
        180.dp, ember,
        imageRes = R.drawable.tumpaksewu),
)

/* ------------------------------------------------------------------ */
/*  Layar utama                                                        */
/* ------------------------------------------------------------------ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(onBack: () -> Unit = {}, onBook: () -> Unit = {}) {
    var query by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf(Category.All) }
    var selected by remember { mutableStateOf<Destination?>(null) }
    val favorites = remember { mutableStateListOf<Int>() }

    val filtered = remember(query, category) {
        sampleDestinations.filter { d ->
            (category == Category.All || d.category == category) &&
                    (query.isBlank() ||
                            d.title.contains(query, ignoreCase = true) ||
                            d.subtitle.contains(query, ignoreCase = true))
        }
    }
    val featured = remember { sampleDestinations.sortedByDescending { it.rating }.take(4) }

    fun toggleFavorite(id: Int) {
        if (!favorites.remove(id)) favorites.add(id)
    }

    Box(Modifier.fillMaxSize().background(Canvas)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            TopBar(onBack)
            SearchField(query) { query = it }
            Spacer(Modifier.height(14.dp))
            CategoryChips(category) { category = it }
            Spacer(Modifier.height(14.dp))

            LazyVerticalStaggeredGrid(
                columns = StaggeredGridCells.Adaptive(minSize = 140.dp), // jumlah kolom menyesuaikan lebar layar
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 20.dp, end = 20.dp, bottom = LocalContentBottomPadding.current
                ),
                verticalItemSpacing = 12.dp,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (query.isBlank() && category == Category.All) {
                    item(span = StaggeredGridItemSpan.FullLine) {
                        FeaturedSection(
                            list = featured,
                            favorites = favorites,
                            onFavorite = ::toggleFavorite,
                            onClick = { selected = it },
                        )
                    }
                    item(span = StaggeredGridItemSpan.FullLine) {
                        SectionTitle("All places", Modifier.padding(top = 4.dp))
                    }
                }

                if (filtered.isEmpty()) {
                    item(span = StaggeredGridItemSpan.FullLine) {
                        Text(
                            "No places found. Try another keyword or category.",
                            modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp),
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            fontFamily = AppFont,
                            fontSize = 14.sp,
                        )
                    }
                }

                items(filtered, key = { it.id }) { d ->
                    DestinationCard(
                        d = d,
                        favorite = d.id in favorites,
                        onFavorite = { toggleFavorite(d.id) },
                        onClick = { selected = d },
                        modifier = Modifier.animateItem(),
                    )
                }
            }
        }
    }

    selected?.let { d ->
        ModalBottomSheet(
            onDismissRequest = { selected = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Color.Transparent,
            dragHandle = null,
        ) {
            DetailSheet(d, onBook = { selected = null; onBook() })
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Header                                                             */
/* ------------------------------------------------------------------ */

@Composable
private fun TopBar(onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircleIconButton(Icons.Rounded.ArrowBackIosNew, "Back", onBack)
        Text(
            "Explore Tourism",
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            fontFamily = AppFont,
            fontWeight = FontWeight.Medium,
            fontSize = 17.sp,
            color = Ink,
        )
        CircleIconButton(Icons.Rounded.Notifications, "Notifications") {}
    }
}

@Composable
private fun CircleIconButton(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .shadow(3.dp, CircleShape)
            .background(Color.White, CircleShape)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = Ink, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    TextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        placeholder = { Text("Search something...", fontFamily = AppFont, fontSize = 14.sp) },
        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Color.Gray) },
        trailingIcon = { Icon(Icons.Rounded.Tune, null, tint = Color.Gray) },
        colors = TextFieldDefaults.colors(
            focusedContainerColor = FieldBg,
            unfocusedContainerColor = FieldBg,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Ink,
        ),
    )
}

@Composable
private fun CategoryChips(selected: Category, onSelect: (Category) -> Unit) {
    LazyRow(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(Category.entries.toList()) { c ->
            val isSel = c == selected
            val bg by animateColorAsState(if (isSel) Ink else Color.White, label = "chipBg")
            val fg by animateColorAsState(if (isSel) Color.White else Ink, label = "chipFg")
            Box(
                Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(bg)
                    .border(BorderStroke(1.dp, if (isSel) Ink else Color(0xFFE3E3E8)), RoundedCornerShape(14.dp))
                    .clickable { onSelect(c) }
                    .padding(horizontal = 16.dp, vertical = 9.dp),
            ) {
                Text(c.label, color = fg, fontFamily = AppFont, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        fontFamily = AppFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        color = Ink,
    )
}

/* ------------------------------------------------------------------ */
/*  Featured (baris horizontal)                                        */
/* ------------------------------------------------------------------ */

@Composable
private fun FeaturedSection(
    list: List<Destination>,
    favorites: List<Int>,
    onFavorite: (Int) -> Unit,
    onClick: (Destination) -> Unit,
) {
    Column {
        SectionTitle("Popular this week")
        Spacer(Modifier.height(10.dp))
        LazyRow(
            // melebar sampai tepi layar walau grid punya padding 20.dp
            modifier = Modifier.layout { measurable, constraints ->
                val extra = 40.dp.roundToPx()
                val p = measurable.measure(constraints.copy(maxWidth = constraints.maxWidth + extra))
                layout(constraints.maxWidth, p.height) { p.place(-extra / 2, 0) }
            },
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(list, key = { it.id }) { d ->
                FeaturedCard(d, d.id in favorites, { onFavorite(d.id) }, { onClick(d) })
            }
        }
    }
}

@Composable
private fun FeaturedCard(d: Destination, favorite: Boolean, onFavorite: () -> Unit, onClick: () -> Unit) {
    Box(
        Modifier
            .width(280.dp)
            .height(176.dp)
            .clip(RoundedCornerShape(26.dp))
            .clickable(onClick = onClick)
    ) {
        DestinationImage(d, Modifier.fillMaxSize())
        Scrim(Modifier.fillMaxSize(), top = 0.05f, bottom = 0.7f)

        RatingPill(d.rating, Modifier.align(Alignment.TopStart).padding(14.dp))
        HeartButton(favorite, onFavorite, Modifier.align(Alignment.TopEnd).padding(12.dp))

        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text(
                d.subtitle, color = Color.White.copy(alpha = 0.75f),
                fontFamily = AppFont, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                d.title, color = Color.White,
                fontFamily = AppFont, fontWeight = FontWeight.SemiBold, fontSize = 18.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Kartu grid (judul di tengah seperti inspirasi)                     */
/* ------------------------------------------------------------------ */

@Composable
private fun DestinationCard(
    d: Destination,
    favorite: Boolean,
    onFavorite: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier
            .fillMaxWidth()
            .height(d.gridHeight)
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
    ) {
        DestinationImage(d, Modifier.fillMaxSize())
        Scrim(Modifier.fillMaxSize(), top = 0.1f, bottom = 0.55f)

        Text(
            d.title,
            modifier = Modifier.align(Alignment.Center).padding(horizontal = 16.dp),
            color = Color.White,
            textAlign = TextAlign.Center,
            fontFamily = AppFont,
            fontWeight = FontWeight.Medium,
            fontSize = 16.sp,
            lineHeight = 21.sp,
        )

        HeartButton(favorite, onFavorite, Modifier.align(Alignment.TopEnd).padding(10.dp))
        RatingPill(d.rating, Modifier.align(Alignment.BottomStart).padding(12.dp))
    }
}

@Composable
private fun DestinationImage(d: Destination, modifier: Modifier) {
    Box(modifier.background(Brush.verticalGradient(d.gradient))) {
        if (d.imageRes != null) {
            Image(
                painter = painterResource(d.imageRes),
                contentDescription = d.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(),
            )
        } else if (d.imageUrl != null) {
            AsyncImage(
                model = d.imageUrl,
                contentDescription = d.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(),
            )
        }
    }
}

@Composable
private fun Scrim(modifier: Modifier, top: Float, bottom: Float) {
    Box(
        modifier.background(
            Brush.verticalGradient(listOf(Color.Black.copy(alpha = top), Color.Black.copy(alpha = bottom)))
        )
    )
}

@Composable
private fun RatingPill(rating: Double, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(Color.Black.copy(alpha = 0.35f))
            .padding(horizontal = 9.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Star, null, tint = Gold, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(3.dp))
        Text("$rating", color = Color.White, fontFamily = AppFont, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun HeartButton(favorite: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val scale by animateFloatAsState(
        targetValue = if (favorite) 1.15f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "heart",
    )
    Box(
        modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.28f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
            contentDescription = "Favorite",
            tint = if (favorite) HeartRed else Color.White,
            modifier = Modifier.size(17.dp).scale(scale),
        )
    }
}

/* ------------------------------------------------------------------ */
/*  Detail (bottom sheet dengan kartu kaca, mirip layar ke-3)          */
/* ------------------------------------------------------------------ */

@Composable
private fun DetailSheet(d: Destination, onBook: () -> Unit = {}) {
    Box(
        Modifier
            .fillMaxWidth()
            .height((androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp * 0.85f).dp.coerceAtMost(560.dp))
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
    ) {
        DestinationImage(d, Modifier.fillMaxSize())
        Scrim(Modifier.fillMaxSize(), top = 0f, bottom = 0.45f)

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Color.Black.copy(alpha = 0.5f))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    d.title, Modifier.weight(1f),
                    color = Color.White, fontFamily = AppFont,
                    fontWeight = FontWeight.Medium, fontSize = 19.sp,
                )
                Icon(Icons.Rounded.Star, null, tint = Gold, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("${d.rating}", color = Color.White, fontFamily = AppFont, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                InfoChip(Icons.Rounded.LocationOn, "${d.subtitle} (${d.distance})", Modifier.weight(1f))
                InfoChip(Icons.Rounded.Schedule, d.duration)
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy((-10).dp)) {
                    listOf("A", "R", "D").forEachIndexed { i, s ->
                        Box(
                            Modifier
                                .size(28.dp)
                                .border(2.dp, Color.White, CircleShape)
                                .background(listOf(HeartRed, Gold, Color(0xFF4DA6FF))[i], CircleShape),
                            contentAlignment = Alignment.Center,
                        ) { Text(s, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Text("199+ people adventure", color = Color.White, fontFamily = AppFont, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text(
                d.description,
                color = Color.White.copy(alpha = 0.8f),
                fontFamily = AppFont, fontSize = 12.sp, lineHeight = 18.sp,
            )
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { /* TODO: buka Google Maps */ },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Ink),
                ) { Text("See On The Map", fontFamily = AppFont, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .clickable(onClick = onBook),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.CalendarMonth, "Book", tint = Ink) }
            }
        }
    }
}

@Composable
private fun InfoChip(icon: ImageVector, text: String, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text(
            text, color = Color.White.copy(alpha = 0.8f),
            fontFamily = AppFont, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.width(10.dp))
    }

}@Preview(showBackground = true)
@Composable
fun ExploreScreenPreview() {
    MaterialTheme {
        ExploreScreen()
    }
}
